Hello Dosto 😎

Let's Start with Basics of Python as this is also important for Devops Engineer to build the logic and Programs.

**What is Python?**

- Python is a Open source, general purpose, high level, and object-oriented programming language.
- It was created by **Guido van Rossum**
- Python consists of vast libraries and various frameworks like Django,Tensorflow, Flask, Pandas, Keras etc.

**How to Install Python?**

You can install Python in your System whether it is window, MacOS, ubuntu, centos etc. Below are the links for the installation:

- [Windows Installation](https://www.python.org/downloads/)
- Ubuntu: apt-get install python3.6

Task1:

1. Install Python in your respective OS, and check the version.
2. Read about different Data Types in Python.

You can get the complete Playlist [here](https://www.youtube.com/watch?v=abPgj_3hzVY&list=PLlfy9GnSVerS_L5z0COaF7rsbgWmJXTOM)🙌

Don't forget to share your Journey over linkedin. Let the community know that you have started another chapter of your Journey.

Happy Learning, Ruko Mat Phod do😃

[← Previous Day](../day12/README.md) | [Next Day →](../day14/README.md)
