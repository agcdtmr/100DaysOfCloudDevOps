Day - 78 (Grafana Cloud)

---

Task - 01

1. Setup alerts for EC2 instance.
2. Setup alerts for AWS Billing Alerts.

---

For Reference: https://www.linkedin.com/posts/chetanrakhra_devops-project-share-activity-7044695663913148416-LfvD?utm_source=share&utm_medium=member_desktop

[← Previous Day](../day77/README.md) | [Next Day →](../day79/README.md)
