# Day 74 - Connecting EC2 with Grafana .

You guys did amazing job last day setting up Grafana on Local 🔥.

Now, let's do one step ahead.

---

Task:

Connect an Linux and one Windows EC2 instance with Grafana and monitor the different components of the server.

---

Don't forget to share this amazing work over LinkedIn and Tag us.

## Happy Learning :)

[← Previous Day](../day73/README.md) | [Next Day →](../day75/README.md)
