# Project-10

=========

# Project Description

The project involves Mounting of AWS S3 Bucket On Amazon EC2 Linux Using S3FS.

This is a AWS Mini Project that will teach you AWS, S3, EC2, S3FS.

## Task-01

- Create IAM user and set policies for the project resources using this [blog](https://medium.com/@chetxn/project-8-devops-implementation-8300b9ed1f2).
- Utilize and make the best use of aws-cli
- Run the Project and share it on LinkedIn :)

Happy Learning :)

[← Previous Day](../day88/README.md) | [Next Day →](../day90/README.md)
